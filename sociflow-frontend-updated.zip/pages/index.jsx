export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold' }}>Welcome to Sociflow 👋</h1>
      <p style={{ marginTop: '1rem' }}>Start by onboarding your workspace.</p>
      <a href="/onboarding/workspace" style={{ color: '#3B82F6', textDecoration: 'underline', display: 'inline-block', marginTop: '1rem' }}>
        → Begin Onboarding
      </a>
    </div>
  );
}